<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Laporan extends REST_Controller {

    //1=masih aktif
    //2=tidak aktif
    //3=sudah tidak aktif


    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    
    }

    function riwayattransaksibycabang_post() {
        $id_cabang = $this->post('id_cabang',TRUE);
        $laporan = $this->db->get_where('transaksi',['id_cabang '=> $id_cabang])->result();
        $this->response(array("transaksi"=>$laporan, 200));
       
    }

    function pendapatantahunanbycabang_post() {
       //pendapatantahunan
       
    }
    function pendapatanbulananbycabang_post() {
        //pendapatantahunan
        
    }

}

?>